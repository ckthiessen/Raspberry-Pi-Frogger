# Raspberry-Pi-Frogger

## Running Instructions

1. make 
2. make run 

Currently will only print out the address of the GPIO base register
