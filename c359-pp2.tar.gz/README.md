# Raspberry-Pi-Frogger

Driver for a SNES Controller. It will output what buttons are pressed in the console.

## Running Instructions

1. make 
2. make run 

